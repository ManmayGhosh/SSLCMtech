#ifndef OPERATIONS_H
#define OPERATIONS_H

// Function declarations
int listPassengers(char* busId);
int countBookings(char* busId);
int sortBusList();
int printBusList();
#endif